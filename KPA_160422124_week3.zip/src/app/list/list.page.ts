import { Component, OnInit } from '@angular/core';

interface Product {
  productName: string,
  productDate: Date,
  productPrice: number,
  productQuantity: number
  productAmount?: number
}

@Component({
  selector: 'app-list',
  templateUrl: './list.page.html',
  styleUrls: ['./list.page.scss'],
  standalone: false
})
export class ListPage implements OnInit {
  currentDate = new Date();
  today_ind():string {
    const day_name = ["Minggu", "Senin", "Selasa", "Rabu", "Kamis", "Jumat", "Sabtu"];
    const day = day_name[this.currentDate.getDay()];
    const d = this.currentDate.getDate();
    const monthNames = ["Januari", "Februari", "Maret", "April", "Mei", "Juni", "Juli", "Agustus", "September", "Oktober", "November", "Desember"];
    const m = monthNames[this.currentDate.getMonth()];
    const y = this.currentDate.getFullYear();
    return day+', '+d+'-'+m+'-'+y;
  }

  product: Product = {
    productName: 'Iphone 14',
    productDate: new Date(),
    productPrice: 14000000,
    productQuantity: 1
  }

  reduceQuantity() {
    if (this.product.productQuantity > 1) {
      this.product.productQuantity--;
    }
  }

  addQuantity() {
    this.product.productQuantity++;
  }

  get productAmount(): number {
    return this.product.productPrice * this.product.productQuantity;
  }

  is5daysago = false;
  numberclicked = 0;
  is5dayslater = false;

  goYesterday() {
    this.currentDate.setDate(this.currentDate.getDate() - 1);
    this.numberclicked++;
    if (this.numberclicked == 5) this.is5daysago = true;
  }

  reset() {
    this.currentDate = new Date();
    this.numberclicked = 0;
    this.is5daysago = false;
    this.is5dayslater = false;
  }

  goTomorrow() {
    this.currentDate.setDate(this.currentDate.getDate() + 1);
    this.numberclicked++;
    if (this.numberclicked == 5) this.is5dayslater = true;
  }

  constructor() { }

  ngOnInit() {
  }
}
